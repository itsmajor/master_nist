[ "`echo 12 u | ./factor 1279`" = "12 41 p3f5c0802ded" ]
